from django.contrib import admin

from .models import Users

admin.site.register(Users)